import { Component, inject, OnInit, computed } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { RouterLink } from '@angular/router';
import { PageShell } from '../layout/page-shell';
import { FavoritesService } from '../services/favorites.service';
import { RecipesService, MealDetail } from '../services/recipes.service';
import { forkJoin, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

@Component({
  selector: 'app-favorites-page',
  standalone: true,
  imports: [CommonModule, PageShell, NgOptimizedImage, RouterLink],
  templateUrl: './favorites.html',
  styleUrl: './favorites.scss'
})
export class FavoritesPage implements OnInit {
  fav = inject(FavoritesService);
  api = inject(RecipesService);

  loading = false;
  error: string | null = null;
  // We'll store fetched meal details (or minimal fallback)
  meals: any[] = [];

  ngOnInit() {
    // Ensure favorites loaded first
    if (!this.fav.favorites().length) this.fav.load();
    this.refreshDetails();
  }

  refreshDetails() {
    const ids = this.fav.favorites().map(f => f.recipeId);
    if (!ids.length) { this.meals = []; return; }
    this.loading = true; this.error = null;
    // Limit fan-out to first 24 to avoid large bursts
    const limited = ids.slice(0, 24);
    forkJoin(limited.map(id => this.api.detail(id).pipe(
      catchError(() => of(null))
    ))).pipe(
      map(results => results.filter(Boolean))
    ).subscribe({
      next: (res) => { this.meals = res as MealDetail[]; this.loading = false; },
      error: () => { this.error = 'Failed to load favorite details'; this.loading = false; }
    });
  }

  unfavorite(id: string) {
    const item = this.fav.favorites().find(f => f.recipeId === id);
    if (!item) return;
    this.fav.removeById(item._id).subscribe({
      next: () => this.meals = this.meals.filter(m => (m as any).id !== id)
    });
  }
}
