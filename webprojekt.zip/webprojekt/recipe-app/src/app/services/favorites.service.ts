import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

interface FavoriteDoc {
  _id: string;
  recipeId: string;
  createdAt: string;
  recipe?: { title: string; slug?: string } | null;
}

@Injectable({ providedIn: 'root' })
export class FavoritesService {
  private http = inject(HttpClient);
  private loadingSig = signal<boolean>(false);
  private errorSig = signal<string | null>(null);
  private listSig = signal<FavoriteDoc[]>([]);

  loading = () => this.loadingSig();
  error = () => this.errorSig();
  favorites = () => this.listSig();
  favoriteIds = computed(() => new Set(this.listSig().map(f => f.recipeId)));

  load() {
    if (this.loadingSig()) return;
    this.loadingSig.set(true);
    this.errorSig.set(null);
    this.http.get<{ total: number; data: FavoriteDoc[] }>(`/api/favorites`)
      .subscribe({
        next: res => { this.listSig.set(res.data); this.loadingSig.set(false); },
        error: err => { this.errorSig.set(err?.error?.message || 'Failed to load favorites'); this.loadingSig.set(false); }
      });
  }

  isFavorited(id: string) { return this.favoriteIds().has(id); }

  add(recipeId: string) {
    return this.http.post<FavoriteDoc>(`/api/favorites`, { recipeId }).pipe(
      tap(doc => this.listSig.set([doc, ...this.listSig()]))
    );
  }

  removeById(id: string) {
    return this.http.delete<{ deleted: true }>(`/api/favorites/${id}`).pipe(
      tap(() => this.listSig.set(this.listSig().filter(f => f._id !== id)))
    );
  }

  removeByRecipe(recipeId: string) {
    // Try by-recipe endpoint first; if 404 fallback to local removal
    return this.http.delete<{ deleted: true }>(`/api/favorites/by-recipe/${recipeId}`).pipe(
      tap(() => this.listSig.set(this.listSig().filter(f => f.recipeId !== recipeId)))
    );
  }

  toggle(recipeId: string): Observable<any> {
    const existing = this.listSig().find(f => f.recipeId === recipeId);
    return existing ? this.removeById(existing._id) : this.add(recipeId);
  }
}
