import { Injectable, signal, inject, PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

interface AuthResponse {
  token: string;
  user: { id: string; email: string };
}

@Injectable({ providedIn: 'root' })
export class AuthService {

  readonly token = signal<string | null>(null);
  readonly userEmail = signal<string | null>(null);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);

  // Use relative API path; dev server proxy (proxy.conf.json) maps /api to backend
  private baseUrl = '/api'; 
  private platformId = inject(PLATFORM_ID);

  constructor(private http: HttpClient, private router: Router) {
    if (isPlatformBrowser(this.platformId)) {
      const stored = localStorage.getItem('token');
      if (stored) this.token.set(stored);
      const storedEmail = localStorage.getItem('userEmail');
      if (storedEmail) this.userEmail.set(storedEmail);
    }
  }

  private setToken(token: string | null) {
    if (isPlatformBrowser(this.platformId)) {
      if (token) localStorage.setItem('token', token); else localStorage.removeItem('token');
    }
    this.token.set(token);
  }

  register(email: string, password: string) {
    this.loading.set(true); this.error.set(null);
    this.http.post<AuthResponse>(`${this.baseUrl}/auth/register`, { email, password })
      .subscribe({
        next: (res) => {
          this.setToken(res.token);
          this.userEmail.set(res.user.email);
          if (isPlatformBrowser(this.platformId)) localStorage.setItem('userEmail', res.user.email);
          this.loading.set(false);
          this.router.navigateByUrl('/home');
        },
        error: (err) => {
          this.loading.set(false);
          const msg = err.error?.error || err.error?.message || 'Registration failed';
          this.error.set(msg);
        }
      });
  }

  login(email: string, password: string) {
    this.loading.set(true); this.error.set(null);
    this.http.post<AuthResponse>(`${this.baseUrl}/auth/login`, { email, password })
      .subscribe({
        next: (res) => {
          this.setToken(res.token);
          this.userEmail.set(res.user.email);
          if (isPlatformBrowser(this.platformId)) localStorage.setItem('userEmail', res.user.email);
          this.loading.set(false);
          this.router.navigateByUrl('/home');
        },
        error: (err) => {
          this.loading.set(false);
          const msg = err.error?.error || err.error?.message || 'Login failed';
          this.error.set(msg);
        }
      });
  }

  logout() {
    this.setToken(null);
    this.userEmail.set(null);
    if (isPlatformBrowser(this.platformId)) localStorage.removeItem('userEmail');
    this.router.navigateByUrl('/login');
  }
}
