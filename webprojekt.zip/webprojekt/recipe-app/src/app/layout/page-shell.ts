import { Component, Input, ViewChild } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Sidebar } from '../sidebar/sidebar';

@Component({
  selector: 'app-page-shell',
  standalone: true,
  imports: [CommonModule, Sidebar],
  templateUrl: './page-shell.html',
  styleUrl: './page-shell.scss'
})
export class PageShell {
  @Input() title = '';
  @Input() hideSidebar = false;

  @ViewChild(Sidebar) sidebar!: Sidebar;

  toggleSidebar() {
    if (this.sidebar) {
      this.sidebar.toggle();
    }
  }
}
