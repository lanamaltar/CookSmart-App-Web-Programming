import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { PageShell } from '../layout/page-shell';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterOutlet, PageShell],
  templateUrl: './landing.html',
  styleUrl: './landing.scss'
})
export class Landing { year = new Date().getFullYear(); }
