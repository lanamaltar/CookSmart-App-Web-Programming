import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, Validators } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterLink],
  template: `
    <div class="form-head">
      <h2>Welcome back</h2>
      <p class="sub">Log in to continue</p>
    </div>
    <form class="modern-form" [formGroup]="form" (ngSubmit)="submit()" novalidate autocomplete="off">
      <div class="field" [class.invalid]="showInvalid('email')">
        <input type="email" formControlName="email" id="loginEmail" placeholder=" " autocomplete="email" />
        <label for="loginEmail">Email</label>
        <div class="msg" *ngIf="showInvalid('email')">Enter a valid email</div>
      </div>
      <div class="field" [class.invalid]="showInvalid('password')">
        <input [type]="pwVisible ? 'text' : 'password'" formControlName="password" id="loginPassword" placeholder=" " autocomplete="current-password" />
        <label for="loginPassword">Password</label>
        <button type="button" class="toggle" (click)="pwVisible = !pwVisible" [attr.aria-label]="pwVisible ? 'Hide password' : 'Show password'">
          <span *ngIf="!pwVisible">Show</span>
          <span *ngIf="pwVisible">Hide</span>
        </button>
        <div class="msg" *ngIf="showInvalid('password')">Min 6 characters</div>
      </div>
      <button class="primary" type="submit" [disabled]="form.invalid || auth.loading()">
        <span class="loader" *ngIf="auth.loading(); else loginText"></span>
        <ng-template #loginText>Login</ng-template>
      </button>
      <p *ngIf="auth.error()" class="feedback error">{{ auth.error() }}</p>
      <p class="switch">Don't have an account? <a routerLink="/register">Register</a></p>
    </form>
  `,
  styles: [`
    :host { display:block; width:100%; margin:0; box-sizing:border-box; }
    @media (max-width:420px){ :host { padding:0 .35rem; } }
    :host-context(body:not(.within-landing)) { min-height:100dvh; display:flex; flex-direction:column; justify-content:center; padding:clamp(1rem,3vw,2rem) 1rem; }

  .form-head { text-align:center; margin:0 0 .32rem; }
  .form-head h2 { margin:0 0 .25rem; font-size:clamp(1.15rem,3.2vw,1.45rem); font-weight:650; letter-spacing:.3px; background:linear-gradient(95deg,#ff8b34,#ffb347); -webkit-background-clip:text; background-clip:text; color:transparent; }
  .form-head .sub { display:block; margin:0; font-size:.8rem; font-weight:500; color:#555d64; letter-spacing:.2px; }

  form.modern-form { display:flex; flex-direction:column; gap:1.5rem; width:100%; padding:1.5rem; box-sizing:border-box; }
    .field { position:relative; display:flex; flex-direction:column; gap:.75rem; }
  .field input { width:100%; font:inherit; padding:.5rem .55rem .42rem; border:1.3px solid #d7dce2; border-radius:11px; background:#f8fafc; outline:none; font-size:.9rem; transition:.25s border, .25s background, .25s box-shadow; box-sizing:border-box; }
    .field input:focus { border-color:#ff9d42; background:#fff; box-shadow:0 0 0 2.5px rgba(255,157,66,0.22); }
  .field label { position:absolute; top:0; left:0; padding:.5rem .55rem; font-size:.68rem; letter-spacing:.45px; text-transform:uppercase; font-weight:600; color:#6a7179; pointer-events:none; transform-origin:left top; transition:.25s transform, .25s color, .25s opacity; }
  .field input:not(:placeholder-shown) + label, .field input:focus + label { transform:translateY(-60%) scale(.74); opacity:.97; color:#ff8b34; }
    .field.invalid input { border-color:#d42828; box-shadow:0 0 0 2.5px rgba(212,40,40,0.15); }
    .field.invalid input:focus { border-color:#d42828; }
  .field .msg { margin-top:.3rem; font-size:.6rem; letter-spacing:.45px; text-transform:uppercase; font-weight:600; color:#d42828; }

  .toggle { position:absolute; top:50%; right:.55rem; transform:translateY(-50%); background:transparent; border:0; font-size:.6rem; letter-spacing:.45px; text-transform:uppercase; font-weight:700; color:#ff8b34; cursor:pointer; padding:.2rem .34rem; border-radius:5px; }
    .toggle:hover { background:rgba(255,140,50,0.08); }

  button.primary { background:linear-gradient(95deg,#ff9d42,#ff7e36 60%, #ffb347); color:#fff; font-weight:600; border:0; padding:.38rem .68rem; border-radius:12px; cursor:pointer; font-size:.92rem; display:flex; align-items:center; justify-content:center; gap:.5rem; box-shadow:none; letter-spacing:.25px; }
    button.primary:hover:not(:disabled) { filter:brightness(1.06); box-shadow:0 7px 22px -6px rgba(255,125,55,0.5); }
    button.primary:disabled { opacity:.6; cursor:not-allowed; }

    .loader { width:16px; height:16px; border:3px solid rgba(255,255,255,0.4); border-top-color:#fff; border-radius:50%; animation:spin .8s linear infinite; }
    @keyframes spin { to { transform:rotate(360deg); } }

  .feedback.error { color:#d42828; font-size:.6rem; letter-spacing:.45px; text-transform:uppercase; font-weight:600; text-align:center; margin:.2rem 0 0; }
  .switch { font-size:.7rem; text-align:center; margin:.22rem 0 0; }
    .switch a { color:#ff7e36; text-decoration:none; font-weight:600; }
    .switch a:hover { text-decoration:underline; }

    /* Narrow width tightening */
  @media (max-width:460px) { .field input { padding:.46rem .5rem .36rem; font-size:.82rem; } button.primary { padding:.5rem .56rem; font-size:.84rem; border-radius:11px; } .form-head h2 { font-size:1.18rem; } .toggle { font-size:.54rem; } }
  @media (max-width:390px) { .field input { padding:.42rem .46rem .34rem; font-size:.78rem; } button.primary { padding:.46rem .5rem; font-size:.78rem; } .toggle { right:.4rem; font-size:.5rem; } }

    /* Short height adjustments */
    @media (max-height:560px) { form.modern-form { gap:.48rem; } }
    @media (max-height:500px) { .switch { font-size:.5rem; } }
  `]
})
export class LoginComponent {
  private fb = inject(FormBuilder);
  auth = inject(AuthService);
  pwVisible = false;

  form = this.fb.group({
    email: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]]
  });

  showInvalid(control: string) {
    const c = this.form.get(control);
    return !!c && c.touched && c.invalid;
  }

  submit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    const { email, password } = this.form.value;
    this.auth.login(email!, password!);
  }
}
