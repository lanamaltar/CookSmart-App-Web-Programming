import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { PageShell } from '../../layout/page-shell';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { RecipesService, MealDetail } from '../../services/recipes.service';
import { forkJoin, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Component({
  selector: 'app-recipes-search',
  standalone: true,
  imports: [CommonModule, PageShell, NgOptimizedImage, RouterLink],
  templateUrl: './recipes-search.html',
  styleUrl: './recipes-search.scss'
})
export class RecipesSearch {
  private api = inject(RecipesService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  q = signal<string>(this.route.snapshot.queryParamMap.get('q') || '');
  results = signal<MealDetail[]>([]);
  loading = signal<boolean>(false);
  error = signal<string | null>(null);
  searched = signal<boolean>(false); // track if user triggered a search explicitly

  // Simple curated list; can be swapped to backend-provided list later
  ingredients = signal<string[]>([
    'chicken','beef','pork','fish','shrimp','egg','cheese','milk','yogurt','butter','tomato','onion','garlic','potato','carrot','rice','pasta','beans','lentils','spinach','broccoli','mushroom','pepper','corn','lemon'
  ]);
  selected = signal<string[]>([]);

  hasSelection = computed(() => this.selected().length > 0);

  constructor() {
    if (this.q()) this.search();
  }

  onSubmit(ev: Event) {
    // Form submit no longer performs a name search; just prevent default.
    ev.preventDefault();
  }

  // Take the current name query and add it as ingredient chip(s)
  addFromQuery() {
    const raw = this.q().trim();
    if (!raw) return;
    // Allow adding multiple at once via comma/semicolon
    const tokens = raw
      .split(/[;,]+/)
      .map(s => s.trim())
      .filter(s => s.length > 0)
      .map(s => s.toLowerCase());
    if (tokens.length === 0) return;

    const ingSet = new Set(this.ingredients());
    const selSet = new Set(this.selected());
    for (const t of tokens) {
      selSet.add(t);
      if (!ingSet.has(t)) ingSet.add(t);
    }
    this.ingredients.set(Array.from(ingSet));
    this.selected.set(Array.from(selSet));
    // Clear the text box; user can now click "Find recipes"
    this.q.set('');
  }

  search() {
    const picked = this.selected();
    this.error.set(null);
    this.searched.set(true);
    if (picked.length > 0) {
      this.searchByIngredients(picked);
    } else {
      // No ingredients selected => nothing to search yet.
      this.results.set([]);
    }
  }

  toggleIngredient(name: string) {
    const set = new Set(this.selected());
    if (set.has(name)) set.delete(name); else set.add(name);
    this.selected.set(Array.from(set));
  }

  clearSelection() {
    this.selected.set([]);
    this.results.set([]);
    this.searched.set(false);
  }

  private searchByIngredients(picked: string[]) {
    this.loading.set(true);
    // Fetch meals for each ingredient with full details for reliable image/title
    const requests = picked.map((ing) => this.api.byIngredient(ing, true, 24).pipe(
      catchError(() => of({ data: [] as MealDetail[] }))
    ));
    forkJoin(requests).pipe(
      map((responses) => {
        // OR matching: union all meals and rank by how many selected ingredients they match
        const lists = responses.map(r => (r as any).data as MealDetail[]);
        if (lists.length === 0) return [] as MealDetail[];

        const counts = new Map<string, { meal: MealDetail; count: number }>();
        for (const list of lists) {
          for (const m of list) {
            const k = m.id;
            const entry = counts.get(k);
            if (entry) entry.count += 1; else counts.set(k, { meal: m, count: 1 });
          }
        }
        // Sort by matched ingredient count desc, then by title
        return Array.from(counts.values())
          .sort((a, b) => (b.count - a.count) || a.meal.title.localeCompare(b.meal.title))
          .map(v => v.meal);
      })
    ).subscribe({
      next: (meals) => { this.results.set(meals); this.loading.set(false); },
      error: () => { this.error.set('Greška pri pretrazi sastojaka'); this.loading.set(false); }
    });
  }
}
