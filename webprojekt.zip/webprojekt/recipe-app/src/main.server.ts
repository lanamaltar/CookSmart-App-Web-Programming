import { bootstrapApplication, BootstrapContext } from '@angular/platform-browser';
import { App } from './app/app';
import { config } from './app/app.config.server';

// Accept BootstrapContext when provided (dev server) but remain callable without it.
export default function bootstrap(context?: BootstrapContext) {
  if (context) {
    return bootstrapApplication(App, config, context);
  }
  return bootstrapApplication(App, config);
}
