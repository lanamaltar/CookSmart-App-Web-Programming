import { MongoClient, ObjectId } from 'mongodb';

const url = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017';
const dbName = process.env.MONGODB_DB || 'examples';
let client; let db;

export async function connectDB() {
  if (db) return db;
  client = new MongoClient(url);
  await client.connect();
  db = client.db(dbName);
  console.log('Mongo connected (native driver)');
  // Indexes (osnovni)
  await db.collection('users').createIndex({ email: 1 }, { unique: true });
  return db;
}

export function usersCollection() {
  if (!db) throw new Error('DB not connected');
  return db.collection('users');
}

export function recipesCollection() {
  if (!db) throw new Error('DB not connected');
  return db.collection('recipes');
}

export { ObjectId };
