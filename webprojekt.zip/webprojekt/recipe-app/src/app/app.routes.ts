import { Routes } from '@angular/router';
import { LoginComponent } from './components/login.component';
import { RegisterComponent } from './components/register.component';
import { Landing as LandingComponent } from './landing/landing';
import { Home } from './home/home';
import { inject } from '@angular/core';
import { AuthService } from './services/auth.service';

const authGuard = () => {
	const auth = inject(AuthService);
	return auth.token() ? true : '/login';
};

export const routes: Routes = [
	{
		path: '',
		component: LandingComponent,
		children: [
			{ path: 'login', component: LoginComponent },
			{ path: 'register', component: RegisterComponent },
			{ path: '', pathMatch: 'full', redirectTo: 'register' }
		]
	},
	{ path: 'home', component: Home, canActivate: [authGuard] },
	// Protected recipe routes (lazy-loaded components)
	{ 
		path: 'recipes', 
		canActivate: [authGuard],
			loadComponent: () => import('./recipes').then(m => m.RecipesList)
	},
	{ 
		path: 'recipes/search', 
		canActivate: [authGuard],
			loadComponent: () => import('./recipes').then(m => m.RecipesSearch)
	}, // keep before :slug
	{ 
		path: 'recipes/:slug', 
		canActivate: [authGuard],
			loadComponent: () => import('./recipes').then(m => m.RecipeDetail)
	},
	{ 
		path: 'shopping-list', 
		canActivate: [authGuard],
		loadComponent: () => import('./shopping-list/shopping-list').then(m => m.ShoppingListComponent)
	},
	{ 
		path: 'favorites',
		canActivate: [authGuard],
		loadComponent: () => import('./favorites/favorites').then(m => m.FavoritesPage)
	},
	{ path: '**', redirectTo: '' }
];
