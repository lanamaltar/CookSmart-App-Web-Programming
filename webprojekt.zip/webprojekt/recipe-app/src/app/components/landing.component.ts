import { Component, signal } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-landing',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink],
  template: `
  <div class="layout">
    <header class="topbar">
  <div class="brand">CookSmart</div>
      <nav>
        <a routerLink="/login" routerLinkActive="active">Login</a>
        <a routerLink="/register" routerLinkActive="active">Register</a>
      </nav>
    </header>
    <div class="hero">
      <div class="bg" aria-hidden="true"></div>
      <div class="overlay"></div>
      <div class="content">
        <div class="intro">
          <h1>Cook smarter.</h1>
          <p class="tagline">Save ingredients, get tailored recipes and plan meals effortlessly.</p>
        </div>
        <div class="panel">
          <router-outlet />
        </div>
      </div>
    </div>
  </div>
  `,
  styles: [`
    :host, .layout, .hero { block-size:100%; inline-size:100%; }
    :host { display:block; }
    body, html { margin:0; padding:0; }
    .topbar { position:fixed; inset-block-start:0; inset-inline:0; height:60px; display:flex; align-items:center; justify-content:space-between; padding:0 2rem; z-index:10; backdrop-filter: blur(6px); background:rgba(20,22,26,0.55); border-bottom:1px solid rgba(255,255,255,0.08); }
    .brand { font-size:1.3rem; font-weight:600; letter-spacing:.5px; color:#fff; }
    nav { display:flex; gap:1.25rem; }
    nav a { color:#d5d8df; text-decoration:none; font-weight:500; font-size:.95rem; position:relative; }
    nav a.active:after { content:''; position:absolute; left:0; right:0; bottom:-6px; height:2px; background:#ffb347; }
    nav a:hover { color:#fff; }
    .hero { position:relative; display:flex; flex-direction:column; }
    .bg { position:absolute; inset:0; background:url('/src/app/assets/1.jpg') center/cover no-repeat; filter:brightness(0.55) contrast(1.05); }
    .overlay { position:absolute; inset:0; background:linear-gradient(120deg, rgba(10,12,16,0.85), rgba(10,12,16,0.4)); }
    .content { position:relative; z-index:2; display:flex; flex:1; align-items:center; justify-content:center; gap:6rem; padding:4rem 3rem 3rem; flex-wrap:wrap; }
    .intro { max-width:420px; color:#f2f4f7; }
    .intro h1 { font-size:clamp(2.4rem,5vw,3.6rem); line-height:1.05; margin:0 0 1rem; background:linear-gradient(95deg,#fff,#f5d08a); -webkit-background-clip:text; color:transparent; }
    .tagline { font-size:1.05rem; opacity:.9; line-height:1.4; }
    .panel { width: min(360px, 100%); background:rgba(255,255,255,0.07); backdrop-filter: blur(14px) saturate(160%); border:1px solid rgba(255,255,255,0.18); padding:2rem 1.75rem 2.25rem; border-radius:18px; box-shadow:0 8px 32px -8px rgba(0,0,0,0.45); color:#fff; }
    .panel h2 { margin-top:0; font-size:1.35rem; }
    .panel form { display:flex; flex-direction:column; gap:1rem; }
    .panel label { display:flex; flex-direction:column; gap:.4rem; font-size:.8rem; letter-spacing:.5px; text-transform:uppercase; font-weight:600; color:#d7dbe3; }
    .panel input { background:#101317; border:1px solid #2a2f36; padding:.75rem .85rem; border-radius:10px; color:#fff; font-size:.9rem; outline:none; transition:.2s border; }
    .panel input:focus { border-color:#ffb347; }
    .panel button { background:linear-gradient(95deg,#ffb347,#ff914d); color:#1a1d21; font-weight:600; border:0; padding:.85rem 1rem; border-radius:10px; cursor:pointer; font-size:.95rem; display:flex; align-items:center; justify-content:center; gap:.35rem; box-shadow:0 4px 18px -4px rgba(255,145,77,0.45); }
    .panel button:disabled { opacity:.6; cursor:not-allowed; }
    .panel .error { color:#ff6262; font-size:.7rem; letter-spacing:.5px; text-transform:uppercase; font-weight:600; }
    .switch { font-size:.8rem; margin-top:.25rem; }
    .switch a { color:#ffb347; text-decoration:none; font-weight:500; }
    .switch a:hover { text-decoration:underline; }
    .foot { position:absolute; inset-inline:0; inset-block-end:0; text-align:center; padding:1rem; font-size:.7rem; letter-spacing:1px; color:#9aa0aa; z-index:2; }
    @media (max-width:920px){ .content { gap:3rem; padding:5rem 2rem 3rem; } .intro { text-align:center; } }
    @media (max-width:560px){ .topbar { padding:0 1rem; } .content { padding:5.5rem 1.25rem 2.5rem; } .panel { padding:1.6rem 1.25rem 2rem; } }
  `]
})
export class LandingComponent { year = new Date().getFullYear(); }
