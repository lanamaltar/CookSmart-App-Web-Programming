import util from 'util';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import { usersCollection } from './db.js';

const randomBytesAsync = util.promisify(crypto.randomBytes);
const pbkdf2Async = util.promisify(crypto.pbkdf2);
const jwtSignAsync = util.promisify(jwt.sign);
const jwtVerifyAsync = util.promisify(jwt.verify);

const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret';

async function hashPassword(password, salt = null) {
  if (!salt) salt = (await randomBytesAsync(16)).toString('hex');
  const hash = (await pbkdf2Async(password, salt, 1000, 64, 'sha512')).toString('hex');
  return { hash, salt };
}

export const hash_password = hashPassword;

export async function credentialsFine(email, password) {
  const user = await usersCollection().findOne({ email });
  if (!user) return { password_correct: false };
  const { hash } = await hashPassword(password, user.passwordSalt);
  if (hash !== user.passwordHash) return { password_correct: false };
  return { password_correct: true, user };
}

export async function create_token(user) {
  return jwtSignAsync({ sub: user._id?.toString?.(), email: user.email }, JWT_SECRET, { expiresIn: '1h' });
}

const EMAIL_REGEX = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

export async function register(req, res) {
  try {
    let { email, password } = req.body;
    if (typeof email !== 'string' || typeof password !== 'string') {
      return res.status(400).json({ message: 'Invalid payload' });
    }
    email = email.trim().toLowerCase();
    if (!EMAIL_REGEX.test(email)) return res.status(400).json({ message: 'Invalid email format' });
    if (password.length < 6) return res.status(400).json({ message: 'Password must be at least 6 characters long' });

    const existing = await usersCollection().findOne({ email });
    if (existing) return res.status(409).json({ message: 'User already exists' });

    const { hash, salt } = await hashPassword(password);
    const insertResult = await usersCollection().insertOne({ email, passwordHash: hash, passwordSalt: salt, createdAt: new Date() });
    // Create a JWT immediately so frontend can treat register same as login
    const token = await create_token({ _id: insertResult.insertedId, email });
    return res.status(201).json({ token, user: { id: insertResult.insertedId, email } });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Server error' });
  }
}

export async function login(req, res) {
  try {
    let { email, password } = req.body;
    if (typeof email !== 'string' || typeof password !== 'string') {
      return res.status(400).json({ message: 'Invalid payload' });
    }
    email = email.trim().toLowerCase();
    const user = await usersCollection().findOne({ email });
    if (!user) return res.status(401).json({ message: 'Invalid credentials' });
    const { hash } = await hashPassword(password, user.passwordSalt);
    if (hash !== user.passwordHash) return res.status(401).json({ message: 'Invalid credentials' });
    const token = await jwtSignAsync({ sub: user._id?.toString?.() || user._id, email: user.email }, JWT_SECRET, { expiresIn: '1h' });
    return res.json({ token, user: { id: user._id, email: user.email } });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ message: 'Server error' });
  }
}

export async function authMiddleware(req, res, next) {
  const token = req.headers['authorization'];
  if (!token) return res.status(401).json({ message: 'Unauthorized' });
  try {
    const payload = await jwtVerifyAsync(token.startsWith('Bearer ') ? token.substring(7) : token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
}
