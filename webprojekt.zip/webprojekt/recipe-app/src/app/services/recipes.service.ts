import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export interface MealSummary {
  id: string;
  title: string;
  thumbnail?: string | null;
}
export interface MealDetail {
  id: string;
  title: string;
  category: string | null;
  area: string | null;
  instructions: string;
  image: string | null;
  youtube: string | null;
  sourceUrl: string | null;
  tags: string[];
  ingredients: { ingredient: string; measure: string }[];
}

@Injectable({ providedIn: 'root' })
export class RecipesService {
  private http = inject(HttpClient);

  categories() {
    return this.http.get<{ data: { id: string; name: string; thumbnail: string; description: string }[] }>(`/api/external/mealdb/categories`);
  }

  byCategory(name: string) {
    return this.http.get<{ category: string; data: MealSummary[] }>(`/api/external/mealdb/by-category`, { params: { c: name } });
  }

  byIngredient(ingredient: string, full = false, limit = 10) {
    return this.http.get<{ data: MealSummary[] | MealDetail[] }>(`/api/external/mealdb`, { params: { ingredient, full: String(full), limit } });
  }

  searchByName(q: string) {
    return this.http.get<{ data: MealDetail[] }>(`/api/external/mealdb/search`, { params: { q } });
  }

  detail(id: string) {
    return this.http.get<MealDetail>(`/api/external/mealdb/${id}`);
  }
}
