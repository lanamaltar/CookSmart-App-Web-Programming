import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { connectDB, recipesCollection } from './db.js';
import { register, login, authMiddleware, credentialsFine, create_token } from './auth.js';
import { mountShoppingList } from './shoppingList.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);


let normalizedRecipes = [];
let ingredientIndex = new Map(); // token -> Set(id)
const normalizedPath = path.join(__dirname, 'recipes.normalized.json');
let favoritesCol; // lazy after connect


const IRREGULAR_PLURALS = new Map([
  ['leaves','leaf'],
  ['loaves','loaf'],
  ['potatoes','potato'],
  ['tomatoes','tomato'],
  ['cherries','cherry'],
  ['berries','berry'],
  ['chilies','chili'],
  ['chilis','chili'],
  ['cloves','clove'],
  ['knives','knife'],
  ['wives','wife'],
  ['halves','half'],
  ['scarves','scarf'],
  ['men','man'],
  ['women','woman'],
  ['children','child'],
  ['teeth','tooth'],
  ['mice','mouse']
]);

function singularize(word='') {
  if (!word) return word;
  if (IRREGULAR_PLURALS.has(word)) return IRREGULAR_PLURALS.get(word);
  if (word.endsWith('ies') && word.length > 4) return word.slice(0, -3) + 'y';
  if (word.endsWith('ves') && word.length > 4) return word.slice(0, -3) + 'f';
  if (word.endsWith('oes') && word.length > 4) return word.slice(0, -2);
  if (word.endsWith('ses') && word.length > 4) return word.slice(0, -2);
  if (word.endsWith('xes') && word.length > 4) return word.slice(0, -2);
  if (word.endsWith('ches') && word.length > 5) return word.slice(0, -2);
  if (word.endsWith('shes') && word.length > 5) return word.slice(0, -2);
  if (word.endsWith('es') && word.length > 3 && !word.endsWith('ses')) return word.slice(0, -2);
  if (word.endsWith('s') && !word.endsWith('ss') && word.length > 3) return word.slice(0, -1);
  return word;
}

function loadNormalized() {
  normalizedRecipes = [];
  ingredientIndex = new Map();
  if (fs.existsSync(normalizedPath)) {
    try {
      normalizedRecipes = JSON.parse(fs.readFileSync(normalizedPath, 'utf8'));
      for (const r of normalizedRecipes) {
        if (Array.isArray(r.ingredient_tokens)) {
          for (const tok of r.ingredient_tokens) {
            const base = singularize(tok);
            const variants = new Set([tok, base]);
            for (const v of variants) {
              if (!ingredientIndex.has(v)) ingredientIndex.set(v, new Set());
              ingredientIndex.get(v).add(r.id);
            }
          }
        }
      }
      console.log(`[recipes] Loaded normalized recipes: ${normalizedRecipes.length}`);
    } catch (e) {
      console.error('Failed to load recipes.normalized.json:', e.message);
    }
  } else {
    console.warn('recipes.normalized.json not found – normalized endpoints will return empty sets.');
  }
}

loadNormalized();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors({ origin: 'http://localhost:4200', credentials: true }));
app.use(express.json());


app.get('/api/health', (_req, res) => res.json({ status: 'ok' }));


app.post('/api/auth/register', register);
app.post('/api/auth/login', login);


app.post('/api/favorites', authMiddleware, async (req, res) => {
  try {
    const { recipeId } = req.body || {};
    if (!recipeId || typeof recipeId !== 'string') return res.status(400).json({ message: 'recipeId required' });
    const doc = { userId: req.user.sub, recipeId, createdAt: new Date() };
    try {
      const r = await favoritesCol.insertOne(doc);
      return res.status(201).json({ _id: r.insertedId, ...doc });
    } catch (e) {
      if (e.code === 11000) return res.status(409).json({ message: 'Already favorited' });
      throw e;
    }
  } catch (err) {
    console.error('Create favorite error', err);
    res.status(500).json({ message: 'Internal error' });
  }
});

// GET favorites list (joined with minimal recipe info if exists)
app.get('/api/favorites', authMiddleware, async (req, res) => {
  try {
    const list = await favoritesCol.find({ userId: req.user.sub }).sort({ createdAt: -1 }).toArray();
    const recipeIds = list.map(f => f.recipeId);
    let recipesMap = new Map();
    if (recipeIds.length) {
      const recs = await recipesCollection().find({ _id: { $in: recipeIds.filter(id => id.length === 24).map(id => ({ id })) } });
      // Above attempt won't work directly (ObjectId mismatch). We'll just skip full join for now or attempt best-effort by storing recipe documents with _id as string originally.
    }
    // Minimal join using normalized set (since normalizedRecipes holds id as r.id) fallback
    for (const fav of list) {
      const norm = normalizedRecipes.find(r => r.id === fav.recipeId);
      if (norm) recipesMap.set(fav.recipeId, { title: norm.title, slug: norm.slug });
    }
    res.json({ total: list.length, data: list.map(f => ({ _id: f._id, recipeId: f.recipeId, createdAt: f.createdAt, recipe: recipesMap.get(f.recipeId) || null })) });
  } catch (err) {
    console.error('List favorites error', err);
    res.status(500).json({ message: 'Internal error' });
  }
});

// DELETE favorite by id
app.delete('/api/favorites/:id', authMiddleware, async (req, res) => {
  try {
    const { id } = req.params;
    const { ObjectId } = await import('mongodb');
    if (!ObjectId.isValid(id)) return res.status(400).json({ message: 'Invalid id' });
    const r = await favoritesCol.deleteOne({ _id: new ObjectId(id), userId: req.user.sub });
    if (!r.deletedCount) return res.status(404).json({ message: 'Not found' });
    res.json({ deleted: true });
  } catch (err) {
    console.error('Delete favorite error', err);
    res.status(500).json({ message: 'Internal error' });
  }
});

app.delete('/api/favorites/by-recipe/:recipeId', authMiddleware, async (req, res) => {
  try {
    const { recipeId } = req.params;
    const r = await favoritesCol.deleteOne({ recipeId, userId: req.user.sub });
    if (!r.deletedCount) return res.status(404).json({ message: 'Not found' });
    res.json({ deleted: true });
  } catch (err) {
    console.error('Delete favorite by recipe error', err);
    res.status(500).json({ message: 'Internal error' });
  }
});


app.get('/api/external/mealdb', async (req, res) => {
  try {
    const ingredient = (req.query.ingredient || '').toString().trim();
    if (!ingredient) return res.status(400).json({ message: 'Query param "ingredient" is required' });
    if (ingredient.length > 50) return res.status(400).json({ message: 'ingredient too long' });

    const url = `https://www.themealdb.com/api/json/v1/1/filter.php?i=${encodeURIComponent(ingredient)}`;
    const fetchImpl = globalThis.fetch ?? (await import('node-fetch')).default;

    const resp = await fetchImpl(url, { headers: { Accept: 'application/json' } });
    if (!resp.ok) return res.status(502).json({ message: 'Upstream error', status: resp.status });

    const json = await resp.json();
    const meals = Array.isArray(json?.meals) ? json.meals : [];

    const minimal = meals.map(m => ({
      id: m.idMeal,
      title: m.strMeal,
      thumbnail: m.strMealThumb
    }));

    // Optional: full details fan-out (limited) via lookup by ID
    const full = ((req.query.full || '').toString().toLowerCase() === 'true') || req.query.full === '1';
    const limitRaw = parseInt(req.query.limit, 10);
    const limit = Number.isFinite(limitRaw) ? Math.max(1, Math.min(25, limitRaw)) : 10;

    if (!full) {
      return res.json({ source: 'themealdb', ingredient, total: minimal.length, data: minimal });
    }

    const ids = minimal.slice(0, limit).map(m => m.id);
    const detailUrl = (id) => `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${encodeURIComponent(id)}`;

    const normalizeDetail = (meal) => {
      const clean = (v) => (v ?? '').toString().trim();
      const ingredients = [];
      for (let i = 1; i <= 20; i++) {
        const ing = clean(meal[`strIngredient${i}`]);
        const measure = clean(meal[`strMeasure${i}`]);
        if (ing) ingredients.push({ ingredient: ing, measure });
      }
      const tags = clean(meal.strTags)
        ? clean(meal.strTags).split(',').map(t => t.trim()).filter(Boolean)
        : [];
      return {
        id: meal.idMeal,
        title: meal.strMeal,
        category: clean(meal.strCategory) || null,
        area: clean(meal.strArea) || null,
        instructions: clean(meal.strInstructions),
        image: clean(meal.strMealThumb) || null,
        youtube: clean(meal.strYoutube) || null,
        source: clean(meal.strSource) || null,
        tags,
        ingredients
      };
    };

    const details = await Promise.all(ids.map(async (id) => {
      try {
        const r = await fetchImpl(detailUrl(id), { headers: { Accept: 'application/json' } });
        if (!r.ok) throw new Error(`lookup ${id} status ${r.status}`);
        const j = await r.json();
        const meal = Array.isArray(j?.meals) ? j.meals[0] : null;
        return meal ? normalizeDetail(meal) : { id, error: 'not_found' };
      } catch (e) {
        return { id, error: 'lookup_failed' };
      }
    }));

    res.json({ source: 'themealdb', ingredient, total: minimal.length, limit, data: details });
  } catch (err) {
    console.error('TheMealDB proxy error:', err);
    res.status(500).json({ message: 'Proxy error' });
  }
});


app.get('/api/external/mealdb/categories', async (_req, res) => {
  try {
    const fetchImpl = globalThis.fetch ?? (await import('node-fetch')).default;
    const url = 'https://www.themealdb.com/api/json/v1/1/categories.php';
    const resp = await fetchImpl(url, { headers: { Accept: 'application/json' } });
    if (!resp.ok) return res.status(502).json({ message: 'Upstream error', status: resp.status });
    const json = await resp.json();
    const list = Array.isArray(json?.categories) ? json.categories.map(c => ({
      id: c.idCategory,
      name: c.strCategory,
      thumbnail: c.strCategoryThumb,
      description: (c.strCategoryDescription || '').trim()
    })) : [];
    res.json({ source: 'themealdb', total: list.length, data: list });
  } catch (err) {
    console.error('TheMealDB categories error:', err);
    res.status(500).json({ message: 'Proxy error' });
  }
});



app.get('/api/external/mealdb/by-category', async (req, res) => {
  try {
    const c = (req.query.c || '').toString().trim();
    if (!c) return res.status(400).json({ message: 'Query param "c" (category) is required' });
    const fetchImpl = globalThis.fetch ?? (await import('node-fetch')).default;
    const url = `https://www.themealdb.com/api/json/v1/1/filter.php?c=${encodeURIComponent(c)}`;
    const resp = await fetchImpl(url, { headers: { Accept: 'application/json' } });
    if (!resp.ok) return res.status(502).json({ message: 'Upstream error', status: resp.status });
    const json = await resp.json();
    const meals = Array.isArray(json?.meals) ? json.meals.map(m => ({
      id: m.idMeal,
      title: m.strMeal,
      thumbnail: m.strMealThumb
    })) : [];
    res.json({ source: 'themealdb', category: c, total: meals.length, data: meals });
  } catch (err) {
    console.error('TheMealDB by-category error:', err);
    res.status(500).json({ message: 'Proxy error' });
  }
});



app.get('/api/external/mealdb/search', async (req, res) => {
  try {
    const q = (req.query.q || '').toString().trim();
    if (!q) return res.json({ source: 'themealdb', total: 0, data: [] });
    const fetchImpl = globalThis.fetch ?? (await import('node-fetch')).default;
    const url = `https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(q)}`;
    const resp = await fetchImpl(url, { headers: { Accept: 'application/json' } });
    if (!resp.ok) return res.status(502).json({ message: 'Upstream error', status: resp.status });
    const json = await resp.json();
    const meals = Array.isArray(json?.meals) ? json.meals : [];
    // Normalize a subset of fields for UI
    const data = meals.map(meal => {
      const clean = (v) => (v ?? '').toString().trim();
      const ingredients = [];
      for (let i = 1; i <= 20; i++) {
        const ing = clean(meal[`strIngredient${i}`]);
        const measure = clean(meal[`strMeasure${i}`]);
        if (ing) ingredients.push({ ingredient: ing, measure });
      }
      const tags = clean(meal.strTags)
        ? clean(meal.strTags).split(',').map(t => t.trim()).filter(Boolean)
        : [];
      return {
        id: meal.idMeal,
        title: meal.strMeal,
        category: clean(meal.strCategory) || null,
        area: clean(meal.strArea) || null,
        instructions: clean(meal.strInstructions),
        image: clean(meal.strMealThumb) || null,
        youtube: clean(meal.strYoutube) || null,
        sourceUrl: clean(meal.strSource) || null,
        tags,
        ingredients
      };
    });
    res.json({ source: 'themealdb', q, total: data.length, data });
  } catch (err) {
    console.error('TheMealDB search error:', err);
    res.status(500).json({ message: 'Proxy error' });
  }
});



app.get('/api/external/mealdb/:id', async (req, res) => {
  try {
    const id = (req.params.id || '').toString().trim();
    if (!id) return res.status(400).json({ message: 'id is required' });

    const fetchImpl = globalThis.fetch ?? (await import('node-fetch')).default;
    const url = `https://www.themealdb.com/api/json/v1/1/lookup.php?i=${encodeURIComponent(id)}`;
    const resp = await fetchImpl(url, { headers: { Accept: 'application/json' } });
    if (!resp.ok) return res.status(502).json({ message: 'Upstream error', status: resp.status });
    const json = await resp.json();
    const meal = Array.isArray(json?.meals) ? json.meals[0] : null;
    if (!meal) return res.status(404).json({ message: 'Recipe not found' });

    const clean = (v) => (v ?? '').toString().trim();
    const ingredients = [];
    for (let i = 1; i <= 20; i++) {
      const ing = clean(meal[`strIngredient${i}`]);
      const measure = clean(meal[`strMeasure${i}`]);
      if (ing) ingredients.push({ ingredient: ing, measure });
    }
    const tags = clean(meal.strTags)
      ? clean(meal.strTags).split(',').map(t => t.trim()).filter(Boolean)
      : [];

    res.json({
      source: 'themealdb',
      id: meal.idMeal,
      title: meal.strMeal,
      category: clean(meal.strCategory) || null,
      area: clean(meal.strArea) || null,
      instructions: clean(meal.strInstructions),
      image: clean(meal.strMealThumb) || null,
      youtube: clean(meal.strYoutube) || null,
      sourceUrl: clean(meal.strSource) || null,
      tags,
      ingredients
    });
  } catch (err) {
    console.error('TheMealDB detail proxy error:', err);
    res.status(500).json({ message: 'Proxy error' });
  }
});


app.post('/api/log-in', async (req, res) => {
  const { email, password } = req.body;
  const result = await credentialsFine(email, password);
  if (!result.password_correct) return res.status(401).json({ message: 'Wrong credentials' });
  const token = await create_token(result.user);
  res.json({ message: 'Login successful', token });
});


app.get('/api/recipes', authMiddleware, async (req, res) => {
  const cursor = recipesCollection().find({}).limit(50);
  const list = await cursor.toArray();
  res.json(list);
});


app.get('/api/normalized/recipes', (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const pageSize = Math.min(parseInt(req.query.pageSize) || 20, 100);
  const start = (page - 1) * pageSize;
  const data = normalizedRecipes.slice(start, start + pageSize);
  res.json({ total: normalizedRecipes.length, page, pageSize, data });
});



app.get('/api/normalized/recipes/search', (req, res) => {
  const ingredientsParam = (req.query.ingredients || '').toString().trim();
  if (!ingredientsParam) return res.json({ total: 0, data: [] });
  const rawTokens = ingredientsParam.split(',')
    .map(t => singularize(t.trim().toLowerCase()))
    .filter(Boolean);
  if (!rawTokens.length) return res.json({ total: 0, data: [] });
  const tokens = [...new Set(rawTokens)]; // dedupe
  const mode = (req.query.mode || 'and').toString().toLowerCase();
  const min = parseInt(req.query.min, 10) || 1;

  const tokenMatchMap = new Map(); // recipeId -> Set(tokens matched)
  let resultIds = [];

  if (mode === 'or') {
    for (const t of tokens) {
      const ids = ingredientIndex.get(t);
      if (!ids) continue;
      for (const id of ids) {
        if (!tokenMatchMap.has(id)) tokenMatchMap.set(id, new Set());
        tokenMatchMap.get(id).add(t);
      }
    }
    resultIds = [...tokenMatchMap.entries()].filter(([_, set]) => set.size >= Math.max(1, min)).map(([id]) => id);
  } else { // AND mode
    const sets = tokens.map(t => ingredientIndex.get(t) || new Set());
    if (sets.some(s => s.size === 0)) return res.json({ total: 0, data: [] });
    let intersection = new Set(sets[0]);
    for (let i = 1; i < sets.length; i++) {
      intersection = new Set([...intersection].filter(id => sets[i].has(id)));
      if (intersection.size === 0) break;
    }
    resultIds = [...intersection];
    for (const id of resultIds) tokenMatchMap.set(id, new Set(tokens));
  }

  let results = resultIds.map(id => normalizedRecipes.find(r => r.id === id)).filter(Boolean);
  results = results.map(r => {
    const matched = tokenMatchMap.get(r.id) || new Set();
    return {
      ...r,
      _match: {
        match_count: matched.size,
        matched_tokens: [...matched]
      }
    };
  });
  results.sort((a, b) => {
    const diff = b._match.match_count - a._match.match_count;
    if (diff !== 0) return diff;
    return a.title.localeCompare(b.title);
  });

  res.json({
    total: results.length,
    query: { tokens, mode, min: mode === 'or' ? Math.max(1, min) : undefined },
    data: results
  });
});

app.get('/api/normalized/recipes/:slug', (req, res) => {
  const r = normalizedRecipes.find(r => r.slug === req.params.slug);
  if (!r) return res.status(404).json({ message: 'Recipe not found' });
  res.json(r);
});


app.post('/api/normalized/reload', (req, res) => {
  loadNormalized();
  res.json({ reloaded: true, total: normalizedRecipes.length });
});

app.post('/api/recipes', authMiddleware, async (req, res) => {
  const { title, description, ingredients = [], steps = [] } = req.body;
  if (!title) return res.status(400).json({ message: 'Title required' });
  const doc = { title, description, ingredients, steps, author: req.user.sub, createdAt: new Date() };
  const result = await recipesCollection().insertOne(doc);
  res.status(201).json({ _id: result.insertedId, ...doc });
});


connectDB()
  .then((db) => {
    globalThis.__dbCache = db;
    favoritesCol = db.collection('favorites');
    favoritesCol.createIndex({ userId: 1, recipeId: 1 }, { unique: true }).catch(e => console.error('favorites index error', e));
    mountShoppingList(app, authMiddleware, db);

    app.use((req, res) => {
      res.status(404).json({ message: 'Not found' });
    });

    app.use((err, req, res, _next) => {
      console.error('Unhandled error:', err);
      res.status(500).json({ message: 'Internal server error' });
    });
    app.listen(PORT, () => {
      console.log(`Backend listening on http://localhost:${PORT}`);
    });
  })
  .catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
