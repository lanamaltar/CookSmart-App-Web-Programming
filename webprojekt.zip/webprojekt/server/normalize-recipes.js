// Normalization script for recipes.json -> recipes.normalized.json
// Keeps nulls, adds id, slug, steps (array), ingredient_tokens, primary_ingredients, search_text, timestamps.

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';

const SRC = path.join(process.cwd(), 'server', 'recipes.json');
const DEST = path.join(process.cwd(), 'server', 'recipes.normalized.json');

const STOP_WORDS = new Set([
  'cup','cups','tablespoon','tablespoons','tbsp','teaspoon','teaspoons','tsp',
  'ounce','ounces','oz','g','kg','ml','l','liter','liters',
  'large','small','medium','extra','virgin','extra-virgin','fresh','ground',
  'finely','coarsely','chopped','minced','sliced','divided','optional','plus',
  'to','taste','of','and','or'
]);

function slugify(title) {
  return title.toLowerCase()
    .replace(/[^a-z0-9]+/g,'-')
    .replace(/-{2,}/g,'-')
    .replace(/^-|-$/g,'');
}

function tokenizeIngredient(line) {
  if (!line) return [];
  let s = line.toLowerCase().trim();
  // remove leading quantity/fractions (e.g. "1/4", "2", "1 1/2")
  s = s.replace(/^\d+(?:[\/\d\s.-]*\d)?\s*/,'');
  s = s.replace(/\([^)]*\)/g,' '); // remove parenthetical notes
  const raw = s.split(/[^a-z0-9-]+/).filter(Boolean);
  return raw.filter(w => !STOP_WORDS.has(w) && w.length > 2);
}

function unique(arr) { return Array.from(new Set(arr)); }

function buildSearchText(r) {
  return [
    r.title || '',
    r.description || '',
    (r.ingredients||[]).join(' '),
    Object.values(r.tags||{}).flat().join(' ')
  ].join(' | ').toLowerCase();
}

function normalize() {
  if (!fs.existsSync(SRC)) {
    console.error('Source file not found:', SRC);
    process.exit(1);
  }
  const raw = JSON.parse(fs.readFileSync(SRC,'utf8'));
  const now = new Date().toISOString();

  const out = raw.map((r, idx) => {
    const slug = slugify(r.title || `recipe-${idx+1}`);
    // steps from instructions object
    let steps = [];
    if (r.instructions && typeof r.instructions === 'object') {
      steps = Object.keys(r.instructions)
        .sort((a,b)=>parseInt(a)-parseInt(b))
        .map(k => (r.instructions[k] || '').trim())
        .filter(Boolean);
    }

    const ingredient_tokens = unique((r.ingredients || []).flatMap(tokenizeIngredient));
    const primary_ingredients = ingredient_tokens
      .filter(t => !['salt','water','pepper','oil'].includes(t))
      .slice(0,5);

    return {
      id: idx + 1,
      slug,
      title: r.title,
      description: r.description,
      ingredients: r.ingredients,
      steps,
      instructions: r.instructions, // keep original
      cooking_time: r.cooking_time,
      servings: r.servings,
      ratings: r.ratings,
      tags: r.tags,
      publish_date: r.publish_date,
      image_filename: r.image_filename,
      ingredient_tokens,
      primary_ingredients,
      search_text: buildSearchText(r),
      created_at: now,
      updated_at: now
    };
  });

  fs.writeFileSync(DEST, JSON.stringify(out,null,2),'utf8');
  console.log('Normalized recipes written:', out.length);
}

normalize();
