import { Component, signal, inject, HostBinding, computed, OnInit, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { AuthService } from '../services/auth.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './sidebar.html',
  styleUrl: './sidebar.scss'
})
export class Sidebar implements OnInit {
  private auth = inject(AuthService);
  readonly userEmail = this.auth.userEmail;
  open = signal<boolean>(false); // start closed

  ngOnInit() {
    // Auto-open only on very large screens. When shrinking, sidebar will close
    // to the compact state; at small widths CSS will hide it.
    const FULL_OPEN_BP = 1200; // above this, sidebar opens by default
    this.open.set(window.innerWidth > FULL_OPEN_BP);
  }

  // Reflect open state as a class on host for layout adjustments
  @HostBinding('class.open') get isOpen() { return this.open(); }
  @HostBinding('style.--sidebar-width') get hostSidebarWidth() {
    return this.open() ? '250px' : '84px';
  }

  toggle() { this.open.update(v => !v); }
  close() { this.open.set(false); }
  logout() { this.auth.logout(); }

  // Auto-close/open on resize to follow breakpoints
  @HostListener('window:resize', ['$event'])
  onResize(e: Event) {
    const w = (e?.target as Window)?.innerWidth ?? window.innerWidth;
    const FULL_OPEN_BP = 1200;
    // open only on very large screens; otherwise keep closed (compact or hidden)
    this.open.set(w > FULL_OPEN_BP);
  }
}
