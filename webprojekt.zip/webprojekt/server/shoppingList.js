import { ObjectId } from './db.js';
import { connectDB } from './db.js';

function shoppingListCollection() {
  const db = globalThis.__dbCache; 
  if (db) return db.collection('shopping_list_items');
  throw new Error('DB not attached');
}

export async function ensureShoppingListCollection(db) {
  await db.collection('shopping_list_items').createIndex({ userId: 1, name: 1 });
}

function normalizeItem(doc) {
  return {
    id: doc._id.toString(),
    name: doc.name,
    quantity: doc.quantity || null,
    checked: !!doc.checked,
    recipeId: doc.recipeId || null,
    addedFromRecipe: !!doc.addedFromRecipe,
    createdAt: doc.createdAt,
    updatedAt: doc.updatedAt
  };
}

export function mountShoppingList(app, authMiddleware, db) {
  const col = () => db.collection('shopping_list_items');


  app.get('/api/shopping-list', authMiddleware, async (req, res) => {
    const list = await col().find({ userId: req.user.sub }).sort({ createdAt: 1 }).toArray();
    res.json({ total: list.length, data: list.map(normalizeItem) });
  });


  app.post('/api/shopping-list', authMiddleware, async (req, res) => {
    const { name, quantity } = req.body || {};
    if (typeof name !== 'string' || !name.trim()) return res.status(400).json({ message: 'Name required' });
    const doc = {
      userId: req.user.sub,
      name: name.trim(),
      quantity: typeof quantity === 'string' && quantity.trim() ? quantity.trim() : null,
      checked: false,
      recipeId: null,
      addedFromRecipe: false,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    const r = await col().insertOne(doc);
    res.status(201).json(normalizeItem({ ...doc, _id: r.insertedId }));
  });

  app.post('/api/shopping-list/bulk-from-recipe', authMiddleware, async (req, res) => {
    const { recipeId, items } = req.body || {};
    if (!Array.isArray(items) || !items.length) return res.status(400).json({ message: 'Items array required' });
    const now = new Date();
    const docs = items.filter(it => it && typeof it.name === 'string' && it.name.trim()).map(it => ({
      userId: req.user.sub,
      name: it.name.trim(),
      quantity: typeof it.quantity === 'string' && it.quantity.trim() ? it.quantity.trim() : null,
      checked: false,
      recipeId: recipeId || null,
      addedFromRecipe: true,
      createdAt: now,
      updatedAt: now
    }));
    if (!docs.length) return res.status(400).json({ message: 'No valid items' });
    const r = await col().insertMany(docs);
    const inserted = docs.map((d, idx) => normalizeItem({ ...d, _id: r.insertedIds[idx] }));
    res.status(201).json({ added: inserted.length, data: inserted });
  });

  app.patch('/api/shopping-list/:id', authMiddleware, async (req, res) => {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) return res.status(400).json({ message: 'Invalid id' });
    const { name, quantity, checked } = req.body || {};
    const update = { updatedAt: new Date() };
    if (typeof name === 'string' && name.trim()) update.name = name.trim();
    if (quantity === null || (typeof quantity === 'string' && quantity.trim())) update.quantity = quantity === null ? null : quantity.trim();
    if (typeof checked === 'boolean') update.checked = checked;
    const r = await col().findOneAndUpdate({ _id: new ObjectId(id), userId: req.user.sub }, { $set: update }, { returnDocument: 'after' });
    if (!r.value) return res.status(404).json({ message: 'Not found' });
    res.json(normalizeItem(r.value));
  });

  app.delete('/api/shopping-list/:id', authMiddleware, async (req, res) => {
    const { id } = req.params;
    if (!ObjectId.isValid(id)) return res.status(400).json({ message: 'Invalid id' });
    const r = await col().deleteOne({ _id: new ObjectId(id), userId: req.user.sub });
    if (!r.deletedCount) return res.status(404).json({ message: 'Not found' });
    res.json({ deleted: true });
  });


  app.delete('/api/shopping-list', authMiddleware, async (req, res) => {
    const r = await col().deleteMany({ userId: req.user.sub });
    res.json({ cleared: r.deletedCount });
  });

  app.get('/api/shopping-list/export', authMiddleware, async (req, res) => {
    const format = (req.query.format || 'txt').toString().toLowerCase();
    const list = await col().find({ userId: req.user.sub }).sort({ name: 1 }).toArray();
    if (format === 'json') {
      res.setHeader('Content-Type', 'application/json');
      return res.send(JSON.stringify(list.map(normalizeItem), null, 2));
    }
    const lines = [
      `Shopping List (${new Date().toISOString().slice(0,10)})`,
      '--------------------------------------------------'
    ];
    for (const it of list) {
      const qty = it.quantity ? ` (${it.quantity})` : '';
      lines.push(`${it.name}${qty}`);
    }
    res.setHeader('Content-Type', 'text/plain');
    res.send(lines.join('\n'));
  });
}
