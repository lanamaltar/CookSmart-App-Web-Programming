import { Component, inject, signal } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { PageShell } from '../../layout/page-shell';
import { RouterLink } from '@angular/router';
import { RecipesService, MealSummary } from '../../services/recipes.service';

@Component({
  selector: 'app-recipes-list',
  standalone: true,
  imports: [CommonModule, PageShell, NgOptimizedImage, RouterLink],
  templateUrl: './recipes-list.html',
  styleUrl: './recipes-list.scss'
})
export class RecipesList {
  private api = inject(RecipesService);

  categories = signal<{ id: string; name: string; thumbnail: string; description: string }[]>([]);
  activeCategory = signal<string>('Beef');
  meals = signal<MealSummary[]>([]);
  loading = signal<boolean>(false);
  error = signal<string | null>(null);
  q: string = '';

  constructor() {
    this.loadCategories();
    this.loadMeals(this.activeCategory());
  }

  loadCategories() {
    this.api.categories().subscribe({
      next: (res) => this.categories.set(res.data),
      error: () => this.error.set('Greška pri učitavanju kategorija')
    });
  }

  loadMeals(category: string) {
    this.loading.set(true);
    this.activeCategory.set(category);
    this.api.byCategory(category).subscribe({
      next: (res) => {
        this.meals.set(res.data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Greška pri učitavanju recepata');
        this.loading.set(false);
      }
    });
  }

  onSearchSubmit(ev: Event) {
    ev.preventDefault();
  const term = this.q.trim();
    if (!term) {
      // Empty search -> show category meals again
      this.loadMeals(this.activeCategory());
      return;
    }
    this.loading.set(true);
    this.error.set(null);
  this.api.searchByName(term).subscribe({
      next: (res) => {
        const items = (res.data || []).map(d => ({ id: d.id, title: d.title, thumbnail: d.image } as MealSummary));
        this.meals.set(items);
        this.loading.set(false);
      },
      error: () => {
        this.error.set('Greška pri pretrazi');
        this.loading.set(false);
      }
    });
  }

  clearSearch() {
    this.q = '';
    this.loadMeals(this.activeCategory());
  }

  // Favorite functionality removed from this list view per request
}
