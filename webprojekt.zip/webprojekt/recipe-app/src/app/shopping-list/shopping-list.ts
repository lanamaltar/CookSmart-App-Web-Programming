import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ShoppingListService } from '../services/shopping-list.service';
import { PageShell } from '../layout/page-shell';

@Component({
  standalone: true,
  selector: 'app-shopping-list',
  imports: [CommonModule, FormsModule, PageShell],
  templateUrl: './shopping-list.html',
  styleUrls: ['./shopping-list.scss']
})
export class ShoppingListComponent implements OnInit {
  svc = inject(ShoppingListService);
  name = '';
  quantity = '';

  ngOnInit() {
    console.log('[ShoppingListComponent] ngOnInit');
    this.svc.load();
  }

  addItem() {
    console.log('[ShoppingListComponent] addItem click', { name: this.name, quantity: this.quantity });
    if (!this.name.trim()) { console.log('[ShoppingListComponent] addItem aborted empty name'); return; }
    this.svc.add(this.name.trim(), this.quantity.trim() || undefined).subscribe({
      next: (item) => { console.log('[ShoppingListComponent] add success', item); this.name = ''; this.quantity = ''; },
      error: (e) => { console.warn('[ShoppingListComponent] add error', e); }
    });
  }

  toggle(it: any, checked: boolean) { console.log('[ShoppingListComponent] toggle', it.id, checked); this.svc.toggle(it.id, checked).subscribe(); }
  rename(it: any, name: string, quantity: string | null) { console.log('[ShoppingListComponent] rename', it.id, name, quantity); this.svc.update(it.id, name, quantity).subscribe(); }
  remove(it: any) { console.log('[ShoppingListComponent] remove', it.id); this.svc.remove(it.id).subscribe(); }
  clearAll() {
    console.log('[ShoppingListComponent] clearAll (no confirm)');
    this.svc.clearAll().subscribe();
  }
  downloadTxt() { this.svc.download('txt'); }
  downloadJson() { this.svc.download('json'); }
  normalizeQty(v: string) { return v.trim() ? v.trim() : null; }
  trackId = (_: number, it: any) => it.id;
}
