import { Injectable, signal, computed, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, tap, catchError } from 'rxjs/operators';
import { Observable, throwError } from 'rxjs';

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: string | null;
  checked: boolean;
  recipeId: string | null;
  addedFromRecipe: boolean;
  createdAt: string;
  updatedAt: string;
}

@Injectable({ providedIn: 'root' })
export class ShoppingListService {
  private http = inject(HttpClient);

  readonly items = signal<ShoppingItem[]>([]);
  readonly loading = signal(false);
  readonly error = signal<string | null>(null);
  readonly uncheckedCount = computed(() => this.items().filter(i => !i.checked).length);

  load() {
    this.loading.set(true); this.error.set(null);
    this.http.get<{ data: ShoppingItem[] }>(`/api/shopping-list`).subscribe({
      next: (res) => { this.items.set(res.data); this.loading.set(false); },
      error: (err) => { this.error.set(err.error?.message || 'Failed to load'); this.loading.set(false); }
    });
  }

  add(name: string, quantity?: string): Observable<ShoppingItem> {
    return this.http.post<ShoppingItem>(`/api/shopping-list`, { name, quantity }).pipe(
      tap(item => this.items.set([...this.items(), item])),
      catchError(err => {
        this.error.set(err.error?.message || 'Add failed');
        return throwError(() => err);
      })
    );
  }

  addBulkFromRecipe(recipeId: string | null, ingredients: { ingredient: string; measure: string }[]): Observable<ShoppingItem[]> {
    const payload = {
      recipeId,
      items: ingredients.map(it => ({ name: it.ingredient, quantity: it.measure || undefined }))
    };
    return this.http.post<{ data: ShoppingItem[] }>(`/api/shopping-list/bulk-from-recipe`, payload).pipe(
      map(res => res.data),
      tap(newItems => this.items.set([...this.items(), ...newItems])),
      catchError(err => {
        this.error.set(err.error?.message || 'Bulk add failed');
        return throwError(() => err);
      })
    );
  }

  toggle(id: string, checked: boolean): Observable<ShoppingItem> {
    return this.http.patch<ShoppingItem>(`/api/shopping-list/${id}`, { checked }).pipe(
      tap(updated => this.items.set(this.items().map(i => i.id === id ? updated : i))),
      catchError(err => { this.error.set(err.error?.message || 'Update failed'); return throwError(() => err); })
    );
  }

  update(id: string, name: string, quantity: string | null): Observable<ShoppingItem> {
    return this.http.patch<ShoppingItem>(`/api/shopping-list/${id}`, { name, quantity }).pipe(
      tap(updated => this.items.set(this.items().map(i => i.id === id ? updated : i))),
      catchError(err => { this.error.set(err.error?.message || 'Update failed'); return throwError(() => err); })
    );
  }

  remove(id: string): Observable<{ deleted: boolean }> {
    return this.http.delete<{ deleted: boolean }>(`/api/shopping-list/${id}`).pipe(
      tap(() => this.items.set(this.items().filter(i => i.id !== id))),
      catchError(err => { this.error.set(err.error?.message || 'Delete failed'); return throwError(() => err); })
    );
  }

  clearAll(): Observable<{ cleared: number }> {
    return this.http.delete<{ cleared: number }>(`/api/shopping-list`).pipe(
      tap(() => this.items.set([])),
      catchError(err => { this.error.set(err.error?.message || 'Clear failed'); return throwError(() => err); })
    );
  }

  download(format: 'txt' | 'json' = 'txt') {
    const url = `/api/shopping-list/export?format=${format}`;
    const accept = format === 'json' ? 'application/json' : 'text/plain';
    this.http.get(url, { responseType: 'text', headers: { Accept: accept } }).subscribe({
      next: (content) => {
        const blob = new Blob([content], { type: accept });
        const a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = format === 'json' ? 'shopping-list.json' : 'shopping-list.txt';
        a.click();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);
      },
      error: (err) => {
        this.error.set(err.error?.message || 'Download failed');
      }
    });
  }
}
