import { Component, inject, signal, computed } from '@angular/core';
import { CommonModule, NgOptimizedImage } from '@angular/common';
import { PageShell } from '../../layout/page-shell';
import { ActivatedRoute } from '@angular/router';
import { ShoppingListService } from '../../services/shopping-list.service';
import { RecipesService, MealDetail } from '../../services/recipes.service';
import { FavoritesService } from '../../services/favorites.service';

@Component({
  selector: 'app-recipe-detail',
  standalone: true,
  imports: [CommonModule, PageShell, NgOptimizedImage],
  templateUrl: './recipe-detail.html',
  styleUrl: './recipe-detail.scss'
})
export class RecipeDetail {
  private route = inject(ActivatedRoute);
  private api = inject(RecipesService);
  private shopping = inject(ShoppingListService);
  fav = inject(FavoritesService);

  meal = signal<MealDetail | null>(null);
  loading = signal<boolean>(true);
  error = signal<string | null>(null);
  addingBulk = false;
  addedOk = false;
  addError: string | null = null;

  // Produce normalized instruction steps: combine standalone numeric lines
  // with following text, split on newlines, trim, remove leading numbers or bullets.
  normalizedSteps = computed(() => {
    const m = this.meal();
    if (!m || !m.instructions) return [] as string[];
    const rawLines = m.instructions.split(/\r?\n/).map(l => l.trim());
    const merged: string[] = [];
    for (let i = 0; i < rawLines.length; i++) {
      const line = rawLines[i];
      if (!line) continue; // skip empty
      // If line is just a number (e.g. "1" or "2.") merge with next non-empty
      if (/^\d+[\.)]?$/.test(line)) {
        let next = '';
        let j = i + 1;
        while (j < rawLines.length && !rawLines[j]) j++;
        if (j < rawLines.length) { next = rawLines[j]; i = j; } else { continue; }
        merged.push(next);
        continue;
      }
      merged.push(line);
    }
    const cleaned = merged.map(s => s.replace(/^\d+\s*[).:-]\s*/, '').replace(/^Step\s+\d+[:.-]?\s*/i, '').trim()).filter(Boolean);
    return cleaned;
  });

  isFavorited = computed(() => {
    const m = this.meal();
    if (!m) return false;
    const id: string | undefined = (m as any).id || (m as any).idMeal;
    return id ? this.fav.isFavorited(id) : false;
  });

  toggleFavorite() {
    const m = this.meal();
    if (!m) return;
    const id: string | undefined = (m as any).id || (m as any).idMeal;
    if (!id) return;
    this.fav.toggle(id).subscribe();
  }

  addAllToShoppingList() {
    const m = this.meal();
    if (!m || !Array.isArray((m as any).ingredients) || !(m as any).ingredients.length) return;
    this.addingBulk = true;
    this.addError = null;
    const recipeId: string | null = (m as any).id || (m as any).idMeal || null;
    this.shopping.addBulkFromRecipe(recipeId, (m as any).ingredients || [])
      .subscribe({
        next: () => {
          this.addingBulk = false;
          this.addedOk = true;
          setTimeout(() => this.addedOk = false, 2000);
        },
        error: (err) => {
          this.addingBulk = false;
          this.addError = err?.error?.message || 'Greška';
        }
      });
  }

  constructor() {
    const id = this.route.snapshot.paramMap.get('slug')!; // using id in slug param
    // Ensure favorites loaded once for page so state correct
    this.fav.load();
    this.api.detail(id).subscribe({
      next: (m) => { this.meal.set(m); this.loading.set(false); },
      error: () => { this.error.set('Greška pri učitavanju recepta'); this.loading.set(false); }
    });
  }
}
